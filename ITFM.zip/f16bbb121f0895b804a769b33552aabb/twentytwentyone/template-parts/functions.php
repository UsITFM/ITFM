<?php
/**
 * Functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */


// ... (ваш существующий код) ...

// Функция для вывода записей из категории
function display_category_section($category_slug, $posts_per_page = -1) {
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => $posts_per_page, 
        'category_name' => $category_slug,
        'orderby' => 'date',
        'order' => 'DESC'
    );

    $posts = new WP_Query($args);

    if ($posts->have_posts()) :
        echo '<ul class="posts-list">';
        while ($posts->have_posts()) : $posts->the_post(); ?>
            <li class="post-item">
                <a href="<?php the_permalink(); ?>">
                    <?php if ( has_post_thumbnail() ) : ?>
                        <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title(); ?>">
                    <?php endif; ?>
                    <div class="post-item-content">
                        <h3><?php the_title(); ?></h3>
                        <p class="post-date"><?php echo get_the_date(); ?></p>
                        <p><?php the_excerpt(); ?></p>
                    </div>
                </a>
            </li>
        <?php endwhile;
        echo '</ul>';
    else : ?>
        <p>Записей в этой категории нет.</p>
    <?php endif; 
    wp_reset_postdata(); 
}

// Функция для вывода записей из подкатегории (для Мероприятий)
function display_subcategory_section($subcategory_slug) {
    $args = array(
        'post_type' => 'event',
        'posts_per_page' => -1, 
        'tax_query' => array(
            array(
                'taxonomy' => 'category',
                'field' => 'slug',
                'terms' => array($subcategory_slug),
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    );

    $posts = new WP_Query($args);

    if ($posts->have_posts()) :
        echo '<ul class="posts-list">';
        while ($posts->have_posts()) : $posts->the_post(); ?>
            <li class="post-item">
                <a href="<?php the_permalink(); ?>">
                    <?php if ( has_post_thumbnail() ) : ?>
                        <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title(); ?>">
                    <?php endif; ?>
                    <div class="post-item-content">
                        <h3><?php the_title(); ?></h3>
                        <p class="post-date"><?php echo get_the_date(); ?></p>
                        <p><?php the_excerpt(); ?></p>
                    </div>
                </a>
            </li>
        <?php endwhile;
        echo '</ul>';
    else : ?>
        <p>Записей в этой подкатегории нет.</p>
    <?php endif; 
    wp_reset_postdata(); 
}

// ... (ваш существующий код) ... 
?>